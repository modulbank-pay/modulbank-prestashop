<?php

namespace FPayments;

class FPaymentsConfig {
    const HOST = 'https://pay.modulbank.ru';
    const NAME = 'Modulbank';
    const PREFIX = 'modulbank';
}
